<html>
<head>
<title>
Walk To Remember | Login
</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
<link rel="stylesheet" type="text/css" href="css/style-2.css">
<link rel="icon" type="text/icon" href="img/logo.jpg"/>
</head>
<body>
<div class="container">
<div class="row" align="center">
<div id="space_three">
</div>
<h2>Login</h2>
</div>
</div>
<div id="space">
</div>
<div class="container">
<div class="row">
<div class="col-md-4 col-md-offset-4">
<div class="form-body">
    <div class="tab-content">
        <div id="sectionA" class="tab-pane fade in active">
        <div class="innter-form">
            <form class="sa-innate-form" action="loginuser.php"method="post">
            <label>Email Address</label>
            <input name="email" placeholder="Email" type="text">
            <label>Password</label>
            <input name="password" placeholder="**********" type="password">
           <input  id="loginbutton"name="submit" type="submit" value="Login">
		   
<br><a href="">Forgot Password?</a>
			<hr>
			<center>
			   <ul class="nav nav-tabs final-login">
        <li><a data-toggle="tab" href="registration.php" >Register Now</a></li>
    </ul></center>
            </form>
            </div>

            <div class="social-login">
            <p style="color:#aa3f39;"><hr> </p>
    		<ul>
            <li><a href="https://www.facebook.com/Acekingenore" target="_blank"><i class="fa fa-facebook"></i> F</a></li>
            <li><a href="https://www.instagram.com/ellis_enore/?hl=en"target="_blank"><i class="fa fa-instragram"></i> I</a></li>
            <li><a href="https://twitter.com/Aceking_enore"target="_blank"><i class="fa fa-twitter"></i> T</a></li>
            </ul>
            </div>
     
        </div>
    </div>
    </div>
    </div>
    </div>
    </div>
<footer>
</footer>
</body>
</html>

<?php
include('login.php');
if(isset($_SESSION['login_user'])){
header("location: profile.php");
}
?>