<?php
session_start(); 
$error=''; 
if (isset($_POST['submit'])) {
if (empty($_POST['email']) || empty($_POST['password'])) {
$error = "Email or Password is invalid";
}
else
{
$email=$_POST['email'];
$password=$_POST['password'];
$connection = mysql_connect("localhost", "root", "");
$email = mysql_real_escape_string($email);
$password = mysql_real_escape_string($password);
$db = mysql_select_db("company", $connection);
$query = mysql_query("select * from users where password='$password' AND email='$email'", $connection);
$rows = mysql_num_rows($query);
if($rows>=1)
{
echo"<script>window.location='login.php';window.alert('Welcome To Walk To Remember I Am Genesis Your Personal Website Assistant');</script>";
$_SESSION['login_user']=$email; 
header("location: profile.php");
}
else
{
echo"<script> window.location='loginuser.php'; window.alert('Invalid Email or Password Please Try Again'); </script>";
}
mysql_close($connection); 
}
}
?>