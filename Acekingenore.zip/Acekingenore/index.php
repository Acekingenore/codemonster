<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
	<link rel="icon" type="text/icon" href="img/logo.png"/>
    <meta name="author" content="">

    <title>Artist of Words</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- Custom CSS -->
    <link href="css/stylish-portfolio.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="http://fonts.googleapis.com/css?family=News+Cycle|Shadows+Into+Light
	|Open+Sans|Pacifico|Dancing+Script|Open+Sans|Exo|Source+Sans+Pro:300,400,700,300italic,
	400italic,700italic|Amatic+SC" rel="stylesheet" type="text/css">
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>


</head>

<body>

    <!-- Navigation -->
    <a id="menu-toggle" href="#" class="btn btn-dark btn-lg toggle"><i class="fa fa-bars"></i></a>
    <nav id="sidebar-wrapper">
        <ul class="sidebar-nav">
            <a id="menu-close" href="#" class="btn btn-light btn-lg pull-right toggle"><i class="fa fa-times"></i></a>
            <li class="sidebar-brand">
                <a href="#top"       onclick=$("#menu-close").click();>Hi I'm Joshua Ellis!</a>
            </li>
            <li>
                <a href="#top"       onclick=$("#menu-close").click();><i class="fa fa-home"> &nbsp </i>Home</a>
            </li>
            <li>
                <a href="#about"     onclick=$("#menu-close").click();><i class="fa fa-user"> &nbsp	</i>Prologue</a>
            </li>
            <li>
                <a href="#services"  onclick=$("#menu-close").click();><i class="fa fa-heart"> &nbsp </i>Chapter 1</a>
            </li>
            <li>
                <a href="#portfolio" onclick=$("#menu-close").click();><i class="fa fa-code">&nbsp </i>Chapter 2</a>
            </li>
            <li>
                <a href="#contact"   onclick=$("#menu-close").click();><i class="fa fa-phone">&nbsp	</i>Chapter 3</a>
            </li>
			
        </ul>
    </nav>

    <!-- Header -->
    <header id="top" class="header">
        <div class="text-vertical-center">
            <h1>Artist of Words</h1>
            <h3>I Just Playing With Them</h3>
            <br>
            <a href="#about" class="btn btn-dark btn-lg">Let's Start</a>
        </div>
    </header>

    <!-- About -->
    <section id="about" class="about">
	
			<img src="img/Profile-pic-1.jpg">
			
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <h2>Prologue</h2>
                    <p class="lead">Even Though I Walk Through The Darkest Valley, I Will Fear No Evil, For You Are With Me;<br><a >Psalm 23:4</a>.</p>
					<a href="#services" class="btn btn-dark btn-lg">Next Page</a>
                </div>
            </div>
            <!-- /.Row -->
        </div>
        <!-- /.Container -->
    </section>

    <!-- Services -->
    <section id="services" class="services bg-primary">
        <div class="container">
            <div class="row text-center">
                <div class="col-lg-10 col-lg-offset-1">
                    <h2>Hybrid Programmer</h2>
                    <hr class="small">
                    <div class="row">
                        <div class="col-md-3 col-sm-6">
                            <div class="service-item">
                                <span class="fa-stack fa-4x">
                                <i class="fa fa-circle fa-stack-2x"></i>
                                <i class="fa fa-server fa-stack-1x text-primary"></i>
                            </span>
							<h3 style="font-family:arial;">Database Defender</h3>
                                <h5 style="font-family:arial;">
                                Microsoft Access, Mysql, Oracle     
								
                                </h5>
                                <p></p><br>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6">
                            <div class="service-item">
                                <span class="fa-stack fa-4x">
                                <i class="fa fa-circle fa-stack-2x"></i>
                                <i class="fa fa-code fa-stack-1x text-primary"></i>
                            </span><h3 style="font-family:arial;">Code Monster</h3><h4></h4>
                            
                                <h5 style="font-family:arial;"> 
									C, C#, C++ <br>
									Java, Android, Python, Visual Basic, Swift									
                                </h5>
                                <p></p> <br>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6">
                            <div class="service-item">
                                <span class="fa-stack fa-4x">
                                <i class="fa fa-circle fa-stack-2x"></i>
                                <i class="fa fa-html5 fa-stack-1x text-primary"></i>
                            </span><h3 style="font-family:arial;">Web Ninja</h3>
                            <h5 style="font-family:arial;"> 
									HTML, CSS, Bootstrap,<br>
									PHP, Ajax, J-Query, .Net, JavaScript								
                                </h5>
                                <p></p><br>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6">
                            <div class="service-item">
                                <span class="fa-stack fa-4x">
                                <i class="fa fa-circle fa-stack-2x"></i>
                                <i class="fa fa-wrench fa-stack-1x text-primary"></i>
								
                            </span><h3 style="font-family:arial;">Computer Engineer</h3>
                            
                                <h5 style="font-family:arial;">
									Installing, Maintaining,<br> Configuring,
									 Diagnosing Computer Systems & Networks 
                                    
                                </h5>
                                <p></p><br>
                            </div>
                        </div>
                    </div>
                    <!-- /.row (nested) --><a href="#portfolio" class="btn btn-dark btn-lg">Next Page</a>
                </div>
                <!-- /.col-lg-10 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container -->
    </section>

    <!-- Callout -->


    <!-- Portfolio -->
    <section id="portfolio" class="portfolio">
        <div class="container">
            <div class="row">
                <div class="col-lg-10 col-lg-offset-1 text-center">
                    <h2>Portfolio</h2>
                    <hr class="small">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="portfolio-item">
                                <a href="img/portfolio-1.2.JPG" target="_blank">
                                    <img class="img-portfolio img-responsive" src="img/portfolio-1.2.jpg">
                                </a>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="portfolio-item">
                                <a href="img/portfolio-2.jpg" target="_blank">
                                    <img class="img-portfolio img-responsive" src="img/portfolio-2.jpg">
                                </a>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="portfolio-item">
                                <a href="img/portfolio-3.jpg" target="_blank">
                                    <img class="img-portfolio img-responsive" src="img/portfolio-3.jpg">
                                </a>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="portfolio-item">
                                <a href="img/portfolio-4.jpg" target="_blank">
                                    <img class="img-portfolio img-responsive" src="img/portfolio-4.jpg">
                                </a>
                            </div>
                        </div>
						<div class="col-md-6">
                            <div class="portfolio-item">
                                <a href="img/portfolio-5.jpg" target="_blank">
                                    <img class="img-portfolio img-responsive" src="img/portfolio-5.jpg">
                                </a>
                            </div>
                        </div>
						<div class="col-md-6">
                            <div class="portfolio-item">
                                <a href="img/portfolio-6.jpg" target="_blank">
                                    <img class="img-portfolio img-responsive" src="img/portfolio-6.jpg">
                                </a>
                            </div>
                        </div>
						<div class="col-md-6">
                            <div class="portfolio-item">
                                <a href="img/portfolio-7.jpg" target="_blank">
                                    <img class="img-portfolio img-responsive" src="img/portfolio-7.jpg">
                                </a>
                            </div>
                        </div>
						<div class="col-md-6">
                            <div class="portfolio-item">
                                <a href="img/portfolio-12.jpg" target="_blank">
                                    <img class="img-portfolio img-responsive" src="img/portfolio-12.jpg">
                                </a>
                            </div>
                        </div>
                    </div>
                    <!-- /.row (nested) -->
                    <a href="index-2.php" target="_blank" class="btn btn-dark">View More Items</a><br><br>
					<a href="#contact" class="btn btn-dark btn-lg">Next Page</a>
                </div>
                <!-- /.col-lg-10 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container -->
    </section>

    <!-- Call to Action -->
    <aside class="call-to-action bg-primary">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <h3>We Love God  - We Make Disciple - And We Always Impact Our World</h3>
                    
                </div>
            </div>
        </div>
    </aside>

  

    <!-- Footer -->
    <footer>
        <div class="container">
	
            <div class="row">
                <div class="col-lg-10 col-lg-offset-1 text-center">
                    <h3></h3>
                    <p></p>
                    <ul class="list-unstyled">
					<hr>
<center>
		<h2>Contact Me!</h2></center>
		<p>Leave A Message For Me And I'll Read It Later.</p>
<div id="contact">
	
<form action="index.php" method="post" ><br>
<ul style="list-style:none;" >
<li>Your Full Name:</li><br>
<input type="text" style="font-family:arial;" name="name"  title="Full Name" required><br>
<li>Your Email:</li><br>
<input type="text" style="font-family:arial;" name="email" title="Email" required><br>
<li>Your Message:</li><br>
<textarea style="resize:none;font-family:arial;"rows="3" cols="71"   name="message" maxlength="500" title="Type Your Message Here"></textarea><br/><br/>
<input type="submit" value="Send Message" name="submit" class="submit"style="width:150px;"></ul>
</form>
</div>
<hr><br>                       
                    </ul>
                    <br>
                    <ul class="list-inline">
                        <li>
                            <a href="https://www.facebook.com/Acekingenore" target="_blank"><i class="fa fa-facebook fa-fw fa-3x"></i></a>
                        </li>
                        <li>
                            <a href="https://twitter.com/TheArtistofWord" target="_blank"><i class="fa fa-twitter fa-fw fa-3x"></i></a>
                        </li>
                        <li>
                            <a href="https://www.instagram.com/ellis_enore/?hl=en" target="_blank"><i class="fa fa-instagram fa-fw fa-3x"></i></a>
                        </li><br><br>
						 <li> Send Me An Email<i class="fa fa-envelope-o fa-fw"></i><div href="http://gmail.com/">joshuaenore74@gmail.com</div>
                        </li>
                    </ul>
                    <hr class="small">
                    <p class="text-muted" 
					style="font-family: 'News Cycle', sans-serif;">Copy Right &copy; <?php echo date("Y"); ?> <b>|</b> Web Design and Develop by <b>|</b> Joshua Ellis Dizon Enore</p>
                </div>
            </div>
        </div>
        <a id="to-top" href="#top" class="btn btn-dark btn-lg"><i class="fa fa-chevron-up fa-fw fa-1x"></i></a>
    </footer>

   <!--PHP Program--> 
<?php 
if(isset($_POST['submit'])){
    $to = "acekingenore24@gmail.com";
    $from = $_POST['email']; 
    $name = $_POST['name'];
    $subject = "The Artist of Words";
    $subject2 = "Greetings";
    $message = $name . "Wrote The Following:" . "\n\n" . $_POST['message'];
    $message2 = "Hi " . $name . " Thank you For Sending Me Your Message I Will Read It After A Few Hours";

    $headers = "From:" . $from;
    $headers2 = "From:" . $to;
    mail($to,$subject,$message,$headers);
    mail($from,$subject2,$message2,$headers2); 
    echo "<script> window.location='index.php';window.alert('Your Message Sended. Thank you " . $name . ", I will contact you shortly.');</script>";
    }
?>
    <!-- jQuery -->
    <script src="js/jquery.js"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>
    <!-- Custom Theme JavaScript -->
    <script>
    // Closes the sidebar menu
    $("#menu-close").click(function(e) {
        e.preventDefault();
        $("#sidebar-wrapper").toggleClass("active");
    });
    // Opens the sidebar menu
    $("#menu-toggle").click(function(e) {
        e.preventDefault();
        $("#sidebar-wrapper").toggleClass("active");
    });
    // Scrolls to the selected menu item on the page
    $(function() {
        $('a[href*=#]:not([href=#],[data-toggle],[data-target],[data-slide])').click(function() {
            if (location.pathname.replace(/^\//, '') == this.pathname.replace(/^\//, '') || location.hostname == this.hostname) {
                var target = $(this.hash);
                target = target.length ? target : $('[name=' + this.hash.slice(1) + ']');
                if (target.length) {
                    $('html,body').animate({
                        scrollTop: target.offset().top
                    }, 1000);
                    return false;
                }
            }
        });
    });
    //#to-top button appears after scrolling
    var fixed = false;
    $(document).scroll(function() {
        if ($(this).scrollTop() > 0) {
            if (!fixed) {
                fixed = true;
                // $('#to-top').css({position:'fixed', display:'block'});
                $('#to-top').show("slow", function() {
                    $('#to-top').css({
                        position: 'fixed',
                        display: 'block'
                    });
                });
            }
        } else {
            if (fixed) {
                fixed = false;
                $('#to-top').hide("slow", function() {
                    $('#to-top').css({
                        display: 'none'
                    });
                });
            }
        }
    });
    // Disable Google Maps scrolling
    // See http://stackoverflow.com/a/25904582/1607849
    // Disable scroll zooming and bind back the click event
    var onMapMouseleaveHandler = function(event) {
        var that = $(this);
        that.on('click', onMapClickHandler);
        that.off('mouseleave', onMapMouseleaveHandler);
        that.find('iframe').css("pointer-events", "none");
    }
    var onMapClickHandler = function(event) {
            var that = $(this);
            // Disable the click handler until the user leaves the map area
            that.off('click', onMapClickHandler);
            // Enable scrolling zoom
            that.find('iframe').css("pointer-events", "auto");
            // Handle the mouse leave event
            that.on('mouseleave', onMapMouseleaveHandler);
        }
        // Enable map zooming with mouse scroll when the user clicks the map
    $('.map').on('click', onMapClickHandler);
    </script>

</body>

</html>
