<?php
	@mysql_connect("localhost","root","") or die("Genesis: No Data Are Available, Please Try Again Later");
	@mysql_select_db("myweb") or die("Genesis: No Data Are Available, Please Try Again Later");
?>