<?php

$con = mysql_connect("localhost", "root", "") or die ("Server connection Failed.");
$db = mysql_select_db("myweb", $con) or die ("Database connection Failed.");

?>