<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
	<link rel="icon" type="text/icon" href="img/logo.png"/>
    <meta name="author" content="">

    <title>Underconstruction</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/stylish-portfolio.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="http://fonts.googleapis.com/css?family=News+Cycle|Shadows+Into+Light
	|Open+Sans|Pacifico|Dancing+Script|Open+Sans|Exo|Source+Sans+Pro:300,400,700,300italic,
	400italic,700italic|Amatic+SC" rel="stylesheet" type="text/css">
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>


</head>

<body>


    <!-- Header -->
    <header id="top" class="header">
        <div class="text-vertical-center">
            <h1>This Page Is Underconstruction!</h1>
            <h3>Sorry. But This is Unfinish Business, Maybe You Can Go Back Soon!</h3>
            <br>
            <a href="index.php" class="btn btn-dark btn-lg">Go Back !</a>
        </div>
    </header>

  



</body>

</html>
