<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
	<link rel="icon" type="text/icon" href="img/logo.png"/>
    <meta name="author" content="">

    <title>My Master Piece</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/stylish-portfolio.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="http://fonts.googleapis.com/css?family=News+Cycle|Shadows+Into+Light
	|Open+Sans|Pacifico|Dancing+Script|Open+Sans|Exo|Source+Sans+Pro:300,400,700,300italic,
	400italic,700italic|Amatic+SC" rel="stylesheet" type="text/css">
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>


</head>

<body>
 <!-- Navigation -->
    <a id="menu-toggle" href="#" class="btn btn-dark btn-lg toggle"><i class="fa fa-bars"></i></a>
    <nav id="sidebar-wrapper">
        <ul class="sidebar-nav">
            <a id="menu-close" href="#" class="btn btn-light btn-lg pull-right toggle"><i class="fa fa-times"></i></a>
            <li class="sidebar-brand">
                <a href="#top"  onclick=$("#menu-close").click();>Hi I'm Joshua Ellis!</a>
            </li>
            <li>
                <a href="index.php" onclick=$("#menu-close").click();><i class="fa fa-home"> &nbsp </i>Go To Main Menu</a>
            </li>
           
			
        </ul>
    </nav>

    <!-- Header -->
    <header id="top" class="header">
        <div class="text-vertical-center">
            <h1>Welcome To My World</h1>
            <h3>The Voice of Each Words Will Tell You A Truth</h3>
            <br>
            <a href="#about" class="btn btn-dark btn-lg">Start Now?</a>
        </div>
    </header>

    <!-- About -->
    <section id="about" class="about">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <h2>A Short Prologue</h2>
                    <p class="lead">My Life is Like A Book, Writing A Exciting Chapters And Episodes of My Spiritual Journey</p>
                <div id="space"></div>
				  <a href="#services" class="btn btn-dark btn-lg">Next Page</a>
				</div>
            </div>
            <!-- /.Row -->
        </div>
        <!-- /.Container -->
    </section>

    <!-- Services -->
    <section id="services" class="services bg-primary">
        <div class="container">
            <div class="row text-center">
                <div class="col-lg-10 col-lg-offset-1">
                    <h2>Bulletin</h2>
                    <hr class="small">
                    <div class="row">
                        <div class="col-md-3 col-sm-6" >
                            <div class="service-item">
                              
							  <span class="fa-stack fa-4x" >
                                <i class="fa fa-circle fa-stack-2x"></i>
                                <i class="fa fa-cog fa-stack-1x text-primary"></i>
                            </span>
							<h2></h2>
                                <h4>
                                    <ul style="list-style:none;">
									<li>Attendance Monitoring</li>
									<li>E-Commerce Site</li>
									<li>Inventory</li>
									<li></li>
                                    </ul>
                                </h4>
                                <p></p><br>
                            </a>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6">
                            <div class="service-item">
                                <span class="fa-stack fa-4x">
                                <i class="fa fa-circle fa-stack-2x"></i>
                                <i class="fa fa-image fa-stack-1x text-primary"></i>
                            </span>
                                <h4>
                                    
									
                                </h4>
                                <p></p> <br>
                             
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6">
                            <div class="service-item">
                                <span class="fa-stack fa-4x">
                                <i class="fa fa-circle fa-stack-2x"></i>
                                <i class="fa fa-camera fa-stack-1x text-primary"></i>
                            </span>
                                <h4>
                                    
                                </h4>
                                <p></p><br>
                            
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6">
                            <div class="service-item">
                                <span class="fa-stack fa-4x">
                                <i class="fa fa-circle fa-stack-2x"></i>
                                <i class="fa fa-pencil fa-stack-1x text-primary"></i>
                            </span>
                                <h4>
								
                                    
                                </h4>
                                <p></p><br>
                               
                            </div>
                        </div>
                    </div>
                    <!-- /.row (nested) -->
                </div>
                <!-- /.col-lg-10 -->
            <a href="#portfolio" class="btn btn-dark btn-lg">Next Page</a>
			</div>
			<center>
<h3></h3></center>
            <!-- /.row -->
        </div>
        <!-- /.container -->
    </section>
   

    <!-- Portfolio -->
    <section id="portfolio" class="portfolio">
        <div class="container">
            <div class="row">
                <div class="col-lg-10 col-lg-offset-1 text-center">
                    <h2>About Ellis</h2>
                    <hr class="small"><p style="margin-left:500px; position:absolute;"> <br> <br> <br>
								<s style="margin-left:50px;"></s> Hi I'm Joshua Ellis Enore, 
								My life and my self are not really limited to one thing or aspect. 
								I love to learn and explore new things, expanding my horizon of knowledge in every aspect. 
								Life is so short and this world is so big. There is so much out there to learn.
								I love listening music, reading my weapon which is bible and spreading Good news about it,
								My mantra for life is that believe in your self , stay focused and keep going. 
								If you know what you are doing is not wrong than don’t be afraid from doing it ever.
								Have faith in yourself and on God.Value your relations and people in them. 
								Help those who need you. 
								Give smiles and spread happiness as much you can and it will come back to you in doubles, 
								 <br> <br>I Loving God Continually,
								I Making Disciples Passionately, And  <br> I Impact Our World.
								</p>
                        <div class="col-md-6">
                            <div class="portfolio-item">
                                    <img class="img-portfolio img-responsive" src="img/Profile-pic.jpg">
									</img>
								<a href="#title" class="btn btn-dark btn-lg" style="margin-left:670px;">Next Page</a>
                            </div>
							
                        </div>
                  </div>
                </div>
                <!-- /.col-lg-10 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container -->
    </section>

    <!-- Call to Action -->
   <section id="title" class="title">
    <aside class="call-to-action bg-primary">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <h1 style="color:black;">I Created Words !</h1>
					<h5 >They Just Playing Inside of My Head</h5>
                   
                </div>
            </div>
        </div>
    </aside>
</section>
 <section id="portfolio" class="portfolio">
        <div class="container">
            <div class="row">
               
                <!-- /.col-lg-10 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container -->
    </section>

    <!-- Footer -->
    <footer>
        <div class="container">
	
            <div class="row">
                <div class="col-lg-10 col-lg-offset-1 text-center">
                   

                    <br>
                    <ul class="list-inline">
                        <li>
                            <a href="https://www.facebook.com/Acekingenore" target="_blank"><i class="fa fa-facebook fa-fw fa-3x"></i></a>
                        </li>
                        <li>
                            <a href="https://twitter.com/Aceking_enore" target="_blank"><i class="fa fa-twitter fa-fw fa-3x"></i></a>
                        </li>
                        <li>
                            <a href="https://www.instagram.com/ellis_enore/?hl=en" target="_blank"><i class="fa fa-instagram fa-fw fa-3x"></i></a>
                        </li><br><br>
						 <li><i class="fa fa-envelope-o fa-fw"></i> <a href="http://gmail.com/" target="_blank">joshuaenore74@gmail.com</a>
                        </li>
                    </ul>
                    <hr class="small">
                    <p class="text-muted" 
					style="font-family: 'News Cycle', sans-serif;">Copy Right &copy; <?php echo date("Y"); ?> <b>|</b> Web Design and Develop by <b>|</b> Joshua Ellis Dizon Enore</p>
                </div>
            </div>
        </div>
        <a id="to-top" href="#top" class="btn btn-dark btn-lg"><i class="fa fa-chevron-up fa-fw fa-1x"></i></a>
    </footer>

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script>
    // Closes the sidebar menu
    $("#menu-close").click(function(e) {
        e.preventDefault();
        $("#sidebar-wrapper").toggleClass("active");
    });
    // Opens the sidebar menu
    $("#menu-toggle").click(function(e) {
        e.preventDefault();
        $("#sidebar-wrapper").toggleClass("active");
    });
    // Scrolls to the selected menu item on the page
    $(function() {
        $('a[href*=#]:not([href=#],[data-toggle],[data-target],[data-slide])').click(function() {
            if (location.pathname.replace(/^\//, '') == this.pathname.replace(/^\//, '') || location.hostname == this.hostname) {
                var target = $(this.hash);
                target = target.length ? target : $('[name=' + this.hash.slice(1) + ']');
                if (target.length) {
                    $('html,body').animate({
                        scrollTop: target.offset().top
                    }, 1000);
                    return false;
                }
            }
        });
    });
    //#to-top button appears after scrolling
    var fixed = false;
    $(document).scroll(function() {
        if ($(this).scrollTop() > 250) {
            if (!fixed) {
                fixed = true;
                // $('#to-top').css({position:'fixed', display:'block'});
                $('#to-top').show("slow", function() {
                    $('#to-top').css({
                        position: 'fixed',
                        display: 'block'
                    });
                });
            }
        } else {
            if (fixed) {
                fixed = false;
                $('#to-top').hide("slow", function() {
                    $('#to-top').css({
                        display: 'none'
                    });
                });
            }
        }
    });
    // Disable Google Maps scrolling
    // See http://stackoverflow.com/a/25904582/1607849
    // Disable scroll zooming and bind back the click event
    var onMapMouseleaveHandler = function(event) {
        var that = $(this);
        that.on('click', onMapClickHandler);
        that.off('mouseleave', onMapMouseleaveHandler);
        that.find('iframe').css("pointer-events", "none");
    }
    var onMapClickHandler = function(event) {
            var that = $(this);
            // Disable the click handler until the user leaves the map area
            that.off('click', onMapClickHandler);
            // Enable scrolling zoom
            that.find('iframe').css("pointer-events", "auto");
            // Handle the mouse leave event
            that.on('mouseleave', onMapMouseleaveHandler);
        }
        // Enable map zooming with mouse scroll when the user clicks the map
    $('.map').on('click', onMapClickHandler);
	$(document).ready(function() {
    // Configure/customize these variables.
    var showChar = 100;  // How many characters are shown by default
    var ellipsestext = "";
    var lesstext = "RESULT ";
    var moretext = "RESULT";
    

    $('.more').each(function() {
        var content = $(this).html();
 
        if(content.length > showChar) {
 
            var c = content.substr(0, showChar);
            var h = content.substr(showChar, content.length - showChar);
 
            var html = c + '<span class="moreellipses">' + ellipsestext+ 
			'</span><span class="morecontent"><span>' + h + '</span>&nbsp;&nbsp;<a href="" class="morelink">' + lesstext + '</a></span>';
 
            $(this).html(html);
        }
 
    });
 
    $(".morelink").click(function(){
           if($(this).hasClass("less")) {
            $(this).removeClass("less");
            $(this).html(moretext);
        } else {
            $(this).addClass("less");
            $(this).html(lesstext);
        }
        $(this).parent().prev().toggle();
        $(this).prev().toggle();
        return false;
    });
});
    </script>

</body>

</html>
